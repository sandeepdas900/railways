<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');
 /*
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
*/
 
model('commonDb');
model('dataHandling');
$header='common/header';
  switch($action)
	{
	 	 
		case 'home':
		 	view($header,'master/main');	
		break;
		
		case 'aboutus':
				view($header,'master/about');
		break;
		
		case 'contact':
		 		view($header,'master/contact');
		break;
		case 'gallery':
		 		view($header,'master/gallery');
		break;
		case 'services':
		 		view($header,'master/services');
		break;
		case 'contactform':
				contactdb();
				view($header,'master/contact');
		break;
				
		 
		
	 	case'ajaxAction':
			ajaxActions();
		break;
		
		
		default:
			view($header,'master/main');	
		break;
  	}
 
?>