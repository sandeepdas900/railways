<div>

 <form>
 <input type="hidden" name="action" value="workerAdd" />
<div class="form-group">
 <p>Train number</p> 
	<select class="form-control" id="sel1" name="select"> 
    
 <?php
 
 $sql="select* from trains where t_status=0 order by train_no asc ";
 $result=query($sql);
 $list='';
 
 while($row=fetchArray($result))
 {
	 $list.='
	 
    <option value="'.$row['train_no'].'">'.$row['train_no'].'</option>';  
    
   
  
 }

 echo $list;
  
 
 ?>
 
 </select>
 
 <div>

 <div style="margin-top:4%">
 <div class="col-md-12">
 <div class="col-md-3">
 <span><input type="checkbox" name="policed" id="policed" checked/> Add Police</span>
 </div>
  <div class="col-md-3">
  	<div class="form-group">
    <input type="text" class="form-control" id="t_number" placeholder="policename" name="Policename" required >
     </div>
 </div>
 
 
 
 
 
 
 
  <div class="col-md-3">
<div class="form-group">
    <input type="text" class="form-control" id="t_number" placeholder="policenumber" name="Policenumber"required >
     </div>
 </div>
 
 </div>
 </div>
  </div>
  </div>
  
  
  <div>
 
 <div style="margin-top:4%">
 <div class="col-md-12">
 <div class="col-md-3">
 <span><input type="checkbox" name="tced" id="policed" checked/> Add Tc</span>
 </div>
  <div class="col-md-3">
  	<div class="form-group">
    <input type="text" class="form-control" id="t_number" placeholder="tcname" name="tcname"  required >
     </div>
 </div>
  <div class="col-md-3">
<div class="form-group">
    <input type="text" class="form-control" id="t_number" placeholder="tcnumber" name="tcnumber"  required >
     </div>
 </div>
 
 </div>
  </div>
  </div>
  
  
  <div>
 
 <div style="margin-top:4%">
 <div class="col-md-12">
 <div class="col-md-3">
 <span><input type="checkbox" name="sweeped" id="policed" checked/> Add Sweeper</span>
 </div>
  <div class="col-md-3">
  	<div class="form-group">
    <input type="text" class="form-control" id="t_number" placeholder="sweepername" name="sweepername"  required >
     </div>
 </div>
  <div class="col-md-3">
<div class="form-group">
    <input type="text" class="form-control" id="t_number" placeholder="sweepernumber" name="sweepernumber" required >
     </div>
 </div>
 
 </div>
  </div>
  </div>
  
  
  <div style="margin-top:4%">
 <div class="col-md-12">
 <div class="col-md-3">
 <span><input type="checkbox" name="doctor" id="medicaled" checked/> Add Doctor</span>
 </div>
  <div class="col-md-3">
  	<div class="form-group">
    <input type="text" class="form-control" id="doctorname" placeholder="doctorname" name="doctorname" required >
     </div>
 </div>
 
 
 
 
 
 
 
  <div class="col-md-3">
<div class="form-group">
    <input type="text" class="form-control" id="doctornumber" placeholder="doctornumber" name="doctornumber" required >
     </div>
 </div>
 
 </div>
 </div>
  </div>
  </div>
  
   <button type="submit" class="btn btn-success">Add Worker</button>
  </form>
  
  
 