<div class="clearfix">
</div>
<div class="container">

<div class="col-md-12">
<div class="col-md-6 col-sm-4">
<form action="#" method="post">
    <div class="form-group">
    <input type="hidden" name="action" value="insertionTrain">
      <label for="email">Train number</label>
      <input type="text" class="form-control" id="t_number" placeholder="trainnumber" name="trainnumber" >
         <div id="near">
      </div>
    </div>
    <div class="form-group">
      <label for="pwd">Train name</label>
      <input type="text" class="form-control" id="pwd" placeholder="trainname" name="trainname">
   
    </div>
    <div class="checkbox">
      <label><input type="checkbox" name="remember" checked> Remember me</label>
    </div>
    <button type="submit" class="btn btn-danger">Add train</button>
    
  </form>
  
  <a href="?action=inside"><button>back</button></a>
  
  
 </div>
 
 
  </div>
  </div>  
  
