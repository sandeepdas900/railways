<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->
					<div class="inner_content_w3_agile_info">
					

							<div class="registration admin_agile">
								
												<div class="signin-form profile admin">
													<h2>Admin Login</h2>
													<div class="login-form">
														<form action="#" method="post">
                                                        <input type="hidden" name="action" value="login"  />
															<input type="text" name="name" value="Username" name="user" required>
															<input type="password" name="password" value="Password" name="password" required>
															<div class="tp">
																<input type="submit" value="LOGIN">
															</div>
															
														</form>
													</div>
													
												
													 <h6><a href="main-page.html">Forgot password</a><h6>

													 
												</div>

					

				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->
	</div>
<!-- banner -->
<!--copy rights start here-->

<!--copy rights end here-->
<!-- js -->
<div class="clearfix">
</div>
</div>          

<?php
include("view/common/footer.php");
?>
