<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');
 /*
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
*/
 
model('commonDb');
model('dataHandling');
$header='common/header';
$headernew='common/headernew';
  switch($action)
	{
	 	 
		case 'home':
		 	view($header,'master/main');	
		break;
		
		case 'login':
				login();
		break;
		
		case 'inside':
		 		view($header,'master/inside');
		break;
		
		case 'workerAdd':
		 		workerAdd();
				view($header,'master/inside');
		break;
		
		case 'addtrain':
		 		view($headernew,'master/addtrain');
		break;

		case 'addworker':
		 		view($headernew,'master/addworker');
		break;
		
		case 'insertionTrain':
		trainInsert();
		view($headernew,'master/addtrain');
		break;
		

		case 'gallery':
		 		view($header,'master/gallery');
		break;
		case 'services':
		 		view($header,'master/services');
		break;
		case 'contactform':
				contactdb();
				view($header,'master/contact');
		break;
				
		 
		
	 	case'ajaxAction':
			ajaxActions();
		break;
		
		
		default:
			view($header,'master/main');	
		break;
  	}
 
?>