<?php 
 
if ( ! defined('ABSPATH')) exit('No direct script access allowed');

function login()
{
	$name=$_REQUEST['name'];
	$password=$_REQUEST['password'];
	
	$sql="select * from admin where adminuser='".$name."' and password='".$password."'";
	$result=query($sql);
	$i=0;
				while($row = fetchArray($result)) 
				{
					$i++;
					$_SESSION['a_id']=$row['a_id'];
				
				}
				if($i>0)
				{
					 echo "<script>window.location.href='?action=inside'</script>";
				}
				else
				{
					echo "<script>alert('no password match');window.location.href='?action=home'</script>";
					
				}

			
	
	
}
function trainInsert()
{
	$trainnumber=$_REQUEST['trainnumber'];
	$trainname=$_REQUEST['trainname'];
	$sql="insert into trains (train_no,train_name)
			values('".$trainnumber."','".$trainname."')";
	$result=query($sql);
	echo"<script>alert('Inserted value in Table')</script>";
}

function workerAdd()
{
	$select=$_REQUEST['select'];
	$policed=$_REQUEST['policed'];
	$Policename=$_REQUEST['Policename'];
	$Policenumber=$_REQUEST['Policenumber'];
	$tced=$_REQUEST['tced'];
	$tcname=$_REQUEST['tcname'];
	$tcnumber=$_REQUEST['tcnumber'];
	$sweeped=$_REQUEST['sweeped'];
	$sweepername=$_REQUEST['sweepername'];
	$sweepernumber=$_REQUEST['sweepernumber'];
	$doctorname=$_REQUEST['doctorname'];
	$doctornumber=$_REQUEST['doctornumber'];
	
	$sql="insert into currentworker(trainnumber,policed,policename,policenumber,tced,tcname,tcnumber,sweeped,sweepername,sweepernumber,doctorname,doctornumber,Date)
	values('".$select."','".$policed."','".$Policename."','".$Policenumber."','".$tced."','".$tcname."','".$tcnumber."','".$sweeped."','".$sweepername."','".$sweepernumber."','".$doctorname."','".$doctornumber."',now())";
	
$result=query($sql);
}

?>