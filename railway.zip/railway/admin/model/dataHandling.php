<?php	if ( ! defined('ABSPATH')) exit('No direct script access allowed');

	
	function ajaxActions()
	{
	
		$act = $_REQUEST['act'];
		
		switch($act)
		{
			 case 'checktrain':
			 		checktrain();
					$_REQUEST['$result'];
			 break;
			 case 'deleteDietPlan':
			 	deleteDietPlan();
			 break;
			 
			 case 'getArticleDetailsById':
			 	getArticleDetailsById();
			 break;
			 case 'deleteArticle':
			 	deleteArticle();
			 break;
			 
			 
			 
			 case 'checkTrainerEmailId':
			 	checkTrainerEmailId();
			 break;
			 case 'checkMemberEmailId':
			 	checkMemberEmailId();
			 break;
			 
			 
			 // Chatting Start
			 
			 case 'sendMessage':
			 	sendMessage();
			 break;
			 
			 case 'getLastMessage':
			 	getLastMessage();
			 break;
			 
			   //Trainer End Chat
			   
			   	case 'getLastMessage-trainerChat':
					getLastMessageTrainerChat();
				break;
			   	case 'sendMessageByTrainer':
					sendMessageByTrainer();
				break;
				case 'chatClosedByMember':   // For Member
					chatClosedByMember();
				break;
				case 'chatClosedByTrainerDirect':  // For Trainer 
					chatClosedByTrainerDirect();
				break;
				case 'getAllMessage':
					getAllMessage();
				break;
			   // ENd Trainer End Chat
			 
			 
			 // End Chatting
			 
			 case 'userComments':
			 	userComments();
			 break;
			 case 'userCommentsOnForum':
			 	userCommentsOnForum();
			 break;
			 
			 case 'viewPaymentHistoryById':
			 	viewPaymentHistoryById();
			 break;
			 
			 case 'getAllChectByChatId':
			 	getAllChectByChatId();
			 break;
			 
			 
			 
			 case 'postFeebBack':
			 	postFeebBack();
			 break;
			 
			 
			 case 'getArtistByCategory':
			 	getArtistByCategory();
			 break;
			 
			 
			 case 'closeNotification':
			 	closeNotification();
			 break;
			 case 'checkTrainerMessageRandomly':
			 	checkTrainerMessageRandomly();
			 break;
			 
			 
			 case 'shortByFCcategory':
			 	shortByFCcategory();
			 break;
		}
		
	

}

function shortByFCcategory()
{
	$result=shortByFCcategoryDB();
	$list='';
	$i=1;
	while($resultRow = fetchArray($result))
	{
		if($i==1)
				{
					$list.='<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse'.$i.'">
								'.$resultRow['f_Question'].'</a>
							  <span class="vareview"><a href="'.BASEURL.'Forum-Topic/'.$resultRow['forumId'].'">('.$resultRow['tComments'].')View All Reviews</a></span></h4>
							</div>
							<div id="collapse'.$i.'" class="panel-collapse collapse in">
							  <div class="panel-body">'.$resultRow['fAnswer'].'</div>
							</div>
						  </div>';
				}
				else
				{
					$list.='<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse'.$i.'">
								'.$resultRow['f_Question'].'</a>
							  <span class="vareview"><a href="'.BASEURL.'Forum-Topic/'.$resultRow['forumId'].'">('.$resultRow['tComments'].')View All Reviews</a></span></h4>
							</div>
							<div id="collapse'.$i.'" class="panel-collapse collapse">
							  <div class="panel-body">'.$resultRow['fAnswer'].'</div>
							</div>
						  </div>';
				}
				$i++;
	}
	 echo $list;
}



function checkTrainerMessageRandomly()
{
	$result=checkTrainerMessageRandomlyDB();
	$list='0';
	while($resultRow = fetchArray($result))
	 {
		$list=$resultRow['chatId']."~".$resultRow['chat_memberId']."~".$resultRow['mName'];
	 }
	 echo $list;
}
function closeNotification()
{
	closeNotificationDB();
}

function getArtistByCategory()
{
	$result=getArtistByCategoryDB();
	$list='';
	while($resultRow = fetchArray($result))
	 {
				$name=$resultRow['tName'];
			    $name=str_replace(" ","-",$name);
				$list.='<div class="col-sm-4 team_foot">
							<div class="block">
								<div class="img_block">
									<a href="'.BASEURL.'Trainer-Profile/'.$resultRow['tId'].'">
									<img style="border-radius: 100%;" src="'.BASEURL.$resultRow['tImage'].'" alt="'.$name.'"></a>
								</div>
								<div class="content">
									<label>Name: <span><a href="'.BASEURL.'Trainer-Profile/'.$resultRow['tId'].'">'.$name.'</a></span></label>
									<p>'.$resultRow['tTitle'].'</p>
									<ul class="rating list-inline">';
										 $rr=round($resultRow['rt']);
										 
										for($p=1;$p<=$rr;$p++)
										{
											$list.='<li><a href=""><img src="'.BASEURL.'assets/images/star.png" alt=""></a></li>';
										}
										for($p=5;$p>$rr;$p--)
										{
											$list.='<li><a href=""><img src="'.BASEURL.'assets/images/grey_star.png" alt=""></a></li>';
										}
								 	$list.='</ul>
									<div>';
									 if($resultRow['tIsLogin']==1)
									 {
										  $list.='<div class="chatDiv">
										  			<a style="color:#0F9211;font-weight: 900;" onclick=startChating('.$resultRow['tId'].',"'.$name.'")>
															Chat  
												 		</a>
												 </div>';
								 	 }
									 else
									 {
										 $list.='<div class="chatDiv">
										 		<a style="color:#c70000;font-weight: 900;" onclick=startChating('.$resultRow['tId'].',"'.$name.'")>
										 			Chat 
												 </a>
												 </div>';
									 }
								$list.='</div></div>
							</div>
						</div>';
	 }
		  echo $list;
}


function postFeebBack()
{
	postFeebBackDB();
}


function viewPaymentHistoryById()
{
	$result=viewPaymentHistoryByIdDB();
	$i=1;
	$list=' <table class="table table-bordered" width="100%">';
	while($resultRow = fetchArray($result))
	{
		$list.='<tr>
					<td>Plan Name</td>
					<td>'.$resultRow['planName'].'</td>
				</tr>
				<tr>
					<td>Plan Cost</td>
					<td>'.$resultRow['amount'].'</td>
				</tr>
				<tr>
					<td>Buyer Name</td>
					<td>'.$resultRow['mName'].'</td>
				</tr>
				<tr>
					<td>Date</td>
					<td>'.$resultRow['date'].'</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="button" value="Back"  class="reset-btn" onclick="viewPaymentHistory()" /></td>
				</tr>';
	}
	$list.='</table>';
	echo $list;
}


function getAllChectByChatId()
{
	$result=getAllChectByChatIdDB();
	  $list='<div id="chatTable">
	  			 ';
		$i=1;
		while($resultRow = fetchArray($result))
		{
			if($resultRow['m_Type']=="1") // for send to member
			{
				$list.='<div class="trainerMsg tmessgae" >
						   <span class="author">'.$resultRow['tName'].'</span>
						    <div class="msg-text"><strong>--></strong>'.$resultRow['m_text'].'</div>
						</div>';
			}
			else
			{
				$list.='<div class="memberMsg mmessgae"   >
						  <span class="author ">'.$resultRow['mName'].'(Member)</span>
						  <div class="msg-text"> '.$resultRow['m_text'].' <strong><--</strong></div>
					   </div>';
			}
	 		 
		}
		$list.='</div>';
		echo $list;
}



function deleteArticle()
{
	deleteArticleDB();
	$result=getAllArticleListDB();
	$list='';
			$i=1;
			while($resultRow = fetchArray($result))
			{
				$list.='<tr>
							<td>'.$i++.'</td>
							<td>'.$resultRow['aTitle'].'</td>
							<td><input type="button" value="Update" class="btn" onclick="updateArticle('.$resultRow['taId'].')"></td>
							<td><input type="button" value="Delete" class="btn" onclick="deleteArticle('.$resultRow['taId'].')"></td>
					 	</tr>';
			}
			echo $list;
}


function getArticleDetailsById()
{
	$result=getArticleDetailsByIdDB();
	$list='';
	while($resultRow = fetchArray($result))
	{
		$list.='<form name="trainerArticleU" id="trainerArticleU" method="post" enctype="multipart/form-data"  onsubmit="return checkValidationU()" >
				  <input type="hidden" name="action" value="updateTrainerArticle" />
			 	<input type="hidden" name="bId" value="'.$resultRow['bId'].'">
               <table class="table table-bordered" width="100%">
			   		<tr>
                    <th width="20%">Category</th>
                    <td width="70%">
					 <select name="category" id="categoryU" class="form-control requiredInput">
                    	<option value="0">Select</option>
                        ';
							$sql='select * from forumcategory where fcStatus=1';
							$resultC=query($sql);
						 	while($resultRowC = fetchArray($resultC))
							{
								if($resultRowC['fcId']==$resultRow['bcId'])	
								{
									$list.='<option value="'.$resultRowC['fcId'].'" selected>'.$resultRowC['fcName'].'</option>';
								}
								else
								{
									$list.='<option value="'.$resultRowC['fcId'].'">'.$resultRowC['fcName'].'</option>';
								}
							}  
			 		$list.='</select>
						</td>
                    <td width="5%">&nbsp;</td>
                  </tr>	
				 <tr>
					  <th width="20%">URL</th>
					  <td width="70%"><input type="text" name="url" id="urlU"  value="'.$resultRow['url'].'" class="textbox requiredInput"></td>
					  <td width="5%">&nbsp;</td>
            	</tr>
			      <tr>
                    <th width="20%">Title</th>
                    <td width="70%"><input type="text" name="title" id="titleU" value="'.$resultRow['title'].'" class="form-control requiredInput"></td>
                    <td width="5%">&nbsp;</td>
                  </tr>
                   <tr>
                    <th>Description</th>
                    <td><textarea class="form-control" name="description" id="descriptionU" >'.$resultRow['description'].'</textarea></td>
                    <td width="5%">&nbsp;</td>
                  </tr>
				 <tr>
                    <th>Small Description</th>
                    <td><textarea class="form-control" name="sdescription" id="sdescriptionU" >'.$resultRow['sDescription'].'</textarea></td>
                    <td width="5%">&nbsp;</td>
                  </tr>
				   <tr>
                    <th>Image</th>
                    <td><input type="file" name="image" id="image" class="form-control"></td>
                    <td width="5%">&nbsp;</td>
                  </tr>
				  <tr>
                    <th> </th>
                    <td>
						<img src="'.$resultRow['imagePath'].'" style="width:235px;height:130px;">
						<input type="hidden" name="oldImagePath" value="'.$resultRow['imagePath'].'">
					</td>
                    <td width="5%">&nbsp;</td>
                  </tr>
                  <tr>
                    <td></td>
                    <td><input type="submit" name="add_banner" value="Update" class="btn green" ></td>
                    <td width="5%">&nbsp;</td>
                  </tr>
                </table>
              </form>';
	}
	echo $list;
	
}


function userCommentsOnForum()
{
	userCommentsOnForumDB();
}

function userComments()
{
	userCommentsDB();
}


/* ---------------------------------------------------------------- Chatting Start -------------------------------------------------*/
	//Trainer 
	
	function getAllMessage()
	{
		$result=getAllMessageDB();
		$list='';
			$i=1;
			while($resultRow = fetchArray($result))
			{
				$list.='<tr>
							<td>'.$i++.'</td>
							<td>'.$resultRow['mName'].'</td>
							<td>'.$resultRow['m_text'].'</td>
		 <td><input type="button" value="Reply" class="btn" onclick=startChating('.$resultRow['mId'].','.$resultRow['chatId'].',"'.$resultRow['mName'].'")></td>
					 </tr>';
			}
			echo $list;
	}
	
	function chatClosedByMember()
	{
		chatClosedByTrainerDB();
		$_SESSION['fitnessChatStatus']="";
	    $_SESSION['fitnessChattName']="";
	    $_SESSION['fitnessChattId']="";
		$_SESSION['fitnessChat-chatId']="";
		  
		unset($_SESSION['fitnessChatStatus']);
		unset($_SESSION['fitnessChattName']);
		unset($_SESSION['fitnessChattId']);
		unset($_SESSION['fitnessChat-chatId']);
	}
	
	function sendMessageByTrainer()
	{
		$result=sendMessageByTrainerDB();
		$list='<div id="chatTable">';
		$i=1;
		if($result=="0")
		{
			$list="0";
		}
		else
		{
			
			while($resultRow = fetchArray($result))
			{
				if($resultRow['m_Type']=="1") // for send to member
				{
					$list.='<div class="trainerMsg">
							   <span class="author">'.$resultRow['tName'].'</span>
								<div class="msg-text">'.$resultRow['m_text'].'</div>
							</div>';
				}
				else
				{
					$list.='<div class="memberMsg">
							  <span class="author">'.$resultRow['mName'].'</span>
							  <div class="msg-text">'.$resultRow['m_text'].'</div>
							</div>';
				}
			}
			$list.='</div>';
		}
		echo $list;
	}
	
	function chatClosedByTrainerDirect()
	{
		chatClosedByTrainerDB();
		$_SESSION['fitnessTChatStatus']="";
	    $_SESSION['fitnessTmName']="";
	    $_SESSION['fitnessTChattId']="";
	    $_SESSION['fitnessTmId']="";
		
		
		unset($_SESSION['fitnessTChatStatus']);  
		unset($_SESSION['fitnessTmName']);
		unset($_SESSION['fitnessTChattId']);
		unset($_SESSION['fitnessTmId']);
	}
	
	
	function getLastMessageTrainerChat()
	{
		$result=getLastMessageTrainerChatDB();
	    $list='<div id="chatTable">';
		$i=1;
		
		
		if($result=="0")
		{
			$list="0";
		}
		else
		{
			$_SESSION['fitnessTChatStatus']="1";
			$_SESSION['fitnessTChattId']=$_REQUEST['chatId'];
			if(isset($_REQUEST['mId-Chat']))
			{
				$_SESSION['fitnessTmName']=$_REQUEST['mName-Chat'];
				$_SESSION['fitnessTmId']=$_REQUEST['mId-Chat'];
			}
	    
		
			while($resultRow = fetchArray($result))
			{
				if($resultRow['m_Type']=="1") // for send to member
				{
					$list.='<div class="trainerMsg">
							   <span class="author">'.$resultRow['tName'].'</span>
								<div class="msg-text">'.$resultRow['m_text'].'</div>
							</div>';
				}
				else
				{
					$list.='<div class="memberMsg">
							  <span class="author">'.$resultRow['mName'].'</span>
							  <div class="msg-text">'.$resultRow['m_text'].'</div>
							</div>';
				}
			}
			$list.='</div>';
		}
		
		echo $list;
	}

// END Trainer
 
// Member Messages
function getLastMessage()
{
	$result=getLastMessageDB();
 	
 	$list='<div id="chatTable">
			<input type="hidden" id="chatId" value="'.$result[0].'">';
	$i=1;
	if($result[1]=="0")
	{
		$list="0";
	}
	else
	{
		$_SESSION['fitnessChatStatus']="1";
 	    $_SESSION['fitnessChattId']=$_REQUEST['tId'];
	
		while($resultRow = fetchArray($result[1]))
		{
			if($i==1)
			{
				$_SESSION['fitnessChattName']=$resultRow['tName'];
				$_SESSION['fitnessChat-chatId']=$resultRow['chatId'];
	 		}
		
			if($resultRow['m_Type']=="1") // for send to member
			{
				$list.='<div class="trainerMsg">
						   <span class="author">'.$resultRow['tName'].'</span>
							<div class="msg-text">'.$resultRow['m_text'].'</div>
						</div>';
			}
			else
			{
				$list.='<div class="memberMsg">
						  <span class="author">'.$resultRow['mName'].'</span>
						  <div class="msg-text">'.$resultRow['m_text'].'</div>
						</div>';
			}
			$i++;
		}
		$list.='</div>';
	}
	
	echo $list;
}


function sendMessage()
{
	$result=sendMessageDB();
   
   $list='<div id="chatTable">
		 <input type="hidden" id="chatId" value="'.$result[0].'">';
	$i=1;
	if($result[1]=="0")
	{
		$list="0";
	}
	else
	{
		while($resultRow = fetchArray($result[1]))
		{
			if($resultRow['m_Type']=="1") // for send to member
			{
				$list.='<div class="trainerMsg">
						   <span class="author">'.$resultRow['tName'].'</span>
							<div class="msg-text">'.$resultRow['m_text'].'</div>
						</div>';
			}
			else
			{
				$list.='<div class="memberMsg">
						<span class="author">'.$resultRow['mName'].'</span>
							<div class="msg-text">'.$resultRow['m_text'].'</div>
						</div>';
			}
		}
		$list.='</div>';
	}
	echo $list;
}
/* ---------------------------------------------------------------- Chatting Start -------------------------------------------------*/

function checkMemberEmailId()
{
	$flag=checkMemberEmailIdDB();
	echo $flag;
}

function checkTrainerEmailId()
{
	$flag=checkTrainerEmailIdDB();
	echo $flag;
}

 /* --------------------------------------------------------------  Trainer  Start -------------------------------------------------------------*/

function deleteDietPlan()
{
	deleteDietPlanDB();
	$result=getAllDietPlanByTrainerDB();
	$list='';
	$i=1;
	while($resultRow = fetchArray($result))
	{
		$list.='<tr>
				 <td>'.$i++.'</td>
				 <td>'.$resultRow['planName'].'</td>
				 <td>'.$resultRow['price'].'</td>
				 <td><a href="DemoLink/'.$resultRow['dpId'].'">Payment Link</a></td>
				 <td><input type="button" value="Update" class="btn" onclick="updateDietPlan('.$resultRow['dpId'].')"></td>
				 <td><input type="button" value="Delete" class="btn" onclick="deleteDietPlan('.$resultRow['dpId'].')"></td>
		      </tr>';
	}
	echo $list;
}
function getDietPlanDetailsById()
{
 	$result=getDietPlanDetailsByIdDB();
	$list='';
	$i=1;
	while($resultRow = fetchArray($result))
	{
		$list.='<form name="trainerDietPlanU" id="trainerDietPlanU" method="post" enctype="multipart/form-data"  onsubmit="return checkValidationU()" >
          <input type="hidden" name="action" value="updateTrainerDietPlans" />
		  <input type="hidden" name="dpId" value="'.$resultRow['dpId'].'" />
          <table class="table table-bordered" width="100%">
            <tr>
              <td>Plan Name</td>
              <td><input type="text" value="'.$resultRow['planName'].'" name="planName" id="planNameU" class="textbox requiredInput" /></td>
            </tr>
            <tr>
              <td>Plan Price</td>
              <td><input type="text" value="'.$resultRow['price'].'" name="price" id="priceU" class="textbox requiredInput" /></td>
            </tr>
			<tr>
              <td>Plan Short Description</td>
              <td><textarea name="sDesc" id="sDescU" class="textbox requiredInput">'.$resultRow['sdesc'].'</textarea></td>
            </tr>
			<tr>
              <td>Link</td>
              <td>'.$resultRow['path'].'
			  <input type="hidden" name="oldImagePath" value="'.$resultRow['path'].'">
			  </td>
            </tr>
            <tr>
              <td>Plan Image/PDF/DOC</td>
              <td><input type="file" name="image" id="imageU" class="textbox" /></td>
            </tr>
            <tr>
              <td colspan="2"><input type="submit" value="Update" />
                <input type="button" value="Cancel"  class="reset-btn" onclick="viewPlans()" /></td>
            </tr>
          </table>
        </form>';
	}
	echo $list;
}

/* --------------------------------------------------------------  End  Trainer -------------------------------------------------------------*/
 
  
?>