<?php
		// Database host
	define("DB_HOST", "localhost");
	// Database user
	define("DB_USER", "sandeepd_railway");
	// Database password
	define("DB_PASSWORD", "cubeheap@123");
	// Database name
	define("DB_NAME", "sandeepd_railway");
 
 //website URL
	define("BASEURL", "http://sandeepdas.in/railway/");
	 
	 
 	//Website Name
	define("SITENAME", "ssdecor");
 	//Email address to send mail
	define("SENDMAILFROM", "info@cubeheap.com");
?>
