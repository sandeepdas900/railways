<div class="col-md-12 col-sm-12">


<div class="col-md-6 col-sm-6">
<form method="post" action="#">

<div class="form-group">
  <label for="sel1">Select Train Number</label>
  <select class="form-control" id="sel1" name="selection" required>
   <?php
 
 $sql="select* from trains where t_status=0 order by train_no asc ";
 $result=query($sql);
 $list='';
 
 while($row=fetchArray($result))
 {
	 $list.='
	 
    <option value="'.$row['train_no'].'">'.$row['train_no'].'</option>';  
    
   
  
 }

 echo $list;
  
 
 ?>
  </select>
</div>
</div>

<div class="col-md-6 col-sm-6">
<div class="form-group">
  <label for="usr">Seat $ Coach number</label>
  <input type="text" class="form-control" id="usr" placeholder="write your seat and coach number" name="seatnumber" required>
</div>
</div>
<div id="mains">
   
</div>
<div style="text-align:center;margin-top:1%;">
<button style="width:50%" type="button" class="btn btn-primary" onclick="callcleaner(1)">Call Cleaner</button>
</div>

<div  style="text-align:center;margin-top:1%;">
<button  style="width:50%" type="button" class="btn btn-danger" onclick="police(2)">Passenger security</button>
</div>
<div  style="text-align:center;margin-top:1%;">
<button  style="width:50%" type="button" class="btn btn-info" onclick="tc(3)">iilegal passenger</button>
</div>
<div style="text-align:center;margin-top:1%;">
<button style="width:50%" type="button" class="btn btn-success" onclick="medical(4)">Medical </button>
</div>
</form>
</div>



<script>


function callcleaner(id)
{
	var selection=document.getElementById("sel1").value;
	var seatnumber=document.getElementById("usr").value;
	 
   		 
   		$.ajax({
			url: '?action=ajaxAction&id='+id+'&selection='+selection+'&seatnumber='+seatnumber,
			type: 'POST',
			data: 'act=callcleaner',
			success: function(data)
			{
				  
				document.getElementById("mains").innerHTML=data;
				alert('you Will get our service shortly');
				 
			},
			error: function(e)
			{
				
			}
		 });
	    
}
function police(id)
{
	var selection=document.getElementById("sel1").value;
	var seatnumber=document.getElementById("usr").value;
	 
   		 
   		$.ajax({
			url: '?action=ajaxAction&id='+id+'&selection='+selection+'&seatnumber='+seatnumber,
			type: 'POST',
			data: 'act=police',
			success: function(data)
			{
				  
				document.getElementById("mains").innerHTML=data;
				alert('you Will get our service shortly');
				 
			},
			error: function(e)
			{
				
			}
		 });
	    
}
function tc(id)
{
	var selection=document.getElementById("sel1").value;
	var seatnumber=document.getElementById("usr").value;
	 
   		 
   		$.ajax({
			url: '?action=ajaxAction&id='+id+'&selection='+selection+'&seatnumber='+seatnumber,
			type: 'POST',
			data: 'act=tc',
			success: function(data)
			{
				  
				document.getElementById("mains").innerHTML=data;
				alert('you Will get our service shortly');
				 
			},
			error: function(e)
			{
				
			}
		 });
	    
}
function medical(id)
{
	var selection=document.getElementById("sel1").value;
	var seatnumber=document.getElementById("usr").value;
	 
   		 
   		$.ajax({
			url: '?action=ajaxAction&id='+id+'&selection='+selection+'&seatnumber='+seatnumber,
			type: 'POST',
			data: 'act=medical',
			success: function(data)
			{
				  
				document.getElementById("mains").innerHTML=data;
				alert('you Will get our service shortly');
				 
			},
			error: function(e)
			{
				
			}
		 });
	    
}
</script>