<?php 
 
if ( ! defined('ABSPATH')) exit('No direct script access allowed');

function contactdb()
{
	$name=$_REQUEST['name'];
	$email=$_REQUEST['email'];
	$phone=$_REQUEST['phone'];
	$subject=$_REQUEST['subject'];
	$message=$_REQUEST['message'];
	
	$sql='insert into insertt(email,phone,name,message,subject)
		values("'.$email.'","'.$phone.'","'.$name.'","'.$message.'","'.$subject.'")';
 echo "<script>alert('form submitted')</script>";
	query($sql);
	
	
	
	
	

}

function callcleaner()
{
	$selection=$_REQUEST['selection'];
	$seatnumber=$_REQUEST['seatnumber'];
	$id=$_REQUEST['id'];
	
	$sql="insert into complaint(c_trainno,seatno,c_problem,c_date)
			values('".$selection."','".$seatnumber."',".$id.",now())";
			
	$result=query($sql);
	
	
	
	
	$sql="select * from complaint as c
			left join currentworker as cw on cw.trainnumber=c.c_trainno
			where c.c_trainno='".$selection."' order by cw.Date desc limit 1";
			
	$results=query($sql);
     $cleanernumber='';
	while($row=fetchArray($results))
	{
	    $cleanernumber=$row['sweepernumber'];
	}

	
	// Authorisation details.
	$username = "dassandeep0001@gmail.com";
	$hash = "db447a1d282916085f70c25b7030c1337a2f88c17b303b5be5e655817afb4104";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = $cleanernumber; // A single number or a comma-seperated list of numbers
	$message = 	$seatnumber;
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	
	curl_close($ch);
	

	
}


function callpolice()
{
	$selection=$_REQUEST['selection'];
	$seatnumber=$_REQUEST['seatnumber'];
	$id=$_REQUEST['id'];
	
	$sql="insert into complaint(c_trainno,seatno,c_problem,c_date)
			values('".$selection."','".$seatnumber."',".$id.",now())";
			
	$result=query($sql);
	
		$sql="select * from complaint as c
			left join currentworker as cw on cw.trainnumber=c.c_trainno
			where c.c_trainno='".$selection."' order by cw.Date desc limit 1";
			
	$results=query($sql);
     $policenumber='';
	while($row=fetchArray($results))
	{
	    $policenumber=$row['policenumber'];
	}

	
	// Authorisation details.
	$username = "dassandeep0001@gmail.com";
	$hash = "db447a1d282916085f70c25b7030c1337a2f88c17b303b5be5e655817afb4104";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers =  $policenumber; // A single number or a comma-seperated list of numbers
	$message = 	$seatnumber;
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	
	curl_close($ch);
	

	
}
function calltc()
{
	$selection=$_REQUEST['selection'];
	$seatnumber=$_REQUEST['seatnumber'];
	$id=$_REQUEST['id'];
	
	$sql="insert into complaint(c_trainno,seatno,c_problem,c_date)
			values('".$selection."','".$seatnumber."',".$id.",now())";
			
	$result=query($sql);
	
	
		$sql="select * from complaint as c
			left join currentworker as cw on cw.trainnumber=c.c_trainno
			where c.c_trainno='".$selection."' order by cw.Date desc limit 1";
			
	$results=query($sql);
     $tcnumber='';
	while($row=fetchArray($results))
	{
	    $tcnumber=$row['tcnumber'];
	}

	
	// Authorisation details.
	$username = "dassandeep0001@gmail.com";
	$hash = "db447a1d282916085f70c25b7030c1337a2f88c17b303b5be5e655817afb4104";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = $tcnumber; // A single number or a comma-seperated list of numbers
	$message = 	$seatnumber;
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	
	curl_close($ch);
	

	
}
function callmedical()
{
	$selection=$_REQUEST['selection'];
	$seatnumber=$_REQUEST['seatnumber'];
	$id=$_REQUEST['id'];
	
	$sql="insert into complaint(c_trainno,seatno,c_problem,c_date)
			values('".$selection."','".$seatnumber."',".$id.",now())";
			
	$result=query($sql);

	$sql="select * from complaint as c
			left join currentworker as cw on cw.trainnumber=c.c_trainno
			where c.c_trainno='".$selection."' order by cw.Date desc limit 1";
			
	$results=query($sql);
     $medicalnumber='';
	while($row=fetchArray($results))
	{
	    $medicalnumber=$row['doctornumber'];
	}

	// Authorisation details.
    $username = "dassandeep0001@gmail.com";
	$hash = "db447a1d282916085f70c25b7030c1337a2f88c17b303b5be5e655817afb4104";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = $medicalnumber; // A single number or a comma-seperated list of numbers
	$message = $seatnumber;
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	
	curl_close($ch);
	

	
}


	







?>