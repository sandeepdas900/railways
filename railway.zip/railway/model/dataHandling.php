<?php	if ( ! defined('ABSPATH')) exit('No direct script access allowed');

	
	function ajaxActions()
	{
	
		$act = $_REQUEST['act'];
		
		switch($act)
		{
			 case 'callcleaner':
			 		callcleaner();
					$_REQUEST['$result']=callcDesign();
			 break;
			 
			  case 'police':
			 		callpolice();
					$_REQUEST['$result']=callpDesign();
			 break;
			 
			  case 'tc':
			 		calltc();
					$_REQUEST['$result']=calltDesign();
			 break;
			 
			  case 'medical':
			 		callmedical();
					$_REQUEST['$result']=callmDesign();
			 break;
			 
		}
	
	}
	
	function callcDesign()
{
	$trainno=$_REQUEST['selection'];
	$sql="select * from complaint as c
			left join currentworker as cw on cw.trainnumber=c.c_trainno
			where c.c_trainno='".$trainno."' order by cw.Date desc limit 1";
			
	$result=query($sql);
	$list='<table class="table table-striped">
	<thead>
      <tr>
        <th>Name</th>
        <th>Mobile </th>
      
      </tr>
    </thead>';
	while($row=fetchArray($result))
	{
		$list.="<tbody>
      <tr>
        <td>".$row["sweepername"]."</td>
        <td><a href='tel:".$row["sweepernumber"]."'>".$row["sweepernumber"]."</a></td>
		<td><img src='assets/images/user.png' width='50%' height='50%' /></td>
      </tr>
	 
	  </tbody> ";
	}
	$list.="</table>";
	echo $list;
}


	function callpDesign()
{
	$trainno=$_REQUEST['selection'];
	$sql="select * from complaint as c
			left join currentworker as cw on cw.trainnumber=c.c_trainno
			where c.c_trainno='".$trainno."' order by cw.Date desc limit 1";
			
	$result=query($sql);
	$list='<table class="table table-striped">
	<thead>
      <tr>
        <th>Name</th>
        <th>Mobile </th>
      
      </tr>
    </thead>';
	while($row=fetchArray($result))
	{
		$list.="<tbody>
      <tr>
        <td>".$row["policename"]."</td>
        <td><a href='tel:".$row["policenumber"]."'>".$row["policenumber"]."</a></td>
		<td><img src='assets/images/user.png' width='50%' height='50%' /></td>
      </tr>
	 
	  </tbody> ";
	}
	$list.="</table>";
	echo $list;
}

	function calltDesign()
{
	$trainno=$_REQUEST['selection'];
	$sql="select * from complaint as c
			left join currentworker as cw on cw.trainnumber=c.c_trainno
			where c.c_trainno='".$trainno."' order by cw.Date desc limit 1";
			
	$result=query($sql);
	$list='<table class="table table-striped">
	<thead>
      <tr>
        <th>Name</th>
        <th>Mobile </th>
      
      </tr>
    </thead>';
	while($row=fetchArray($result))
	{
		$list.="<tbody>
      <tr>
        <td>".$row["tcname"]."</td>
        <td><a href='tel:".$row["tcnumber"]."'>".$row["tcnumber"]."</a></td>
		<td><img src='assets/images/user.png' width='50%' height='50%' /></td>
      </tr>
	 
	  </tbody> ";
	}
	$list.="</table>";
	echo $list;
}

	function callmDesign()
{
	$trainno=$_REQUEST['selection'];
	$sql="select * from complaint as c
			left join currentworker as cw on cw.trainnumber=c.c_trainno
			where c.c_trainno='".$trainno."' order by cw.Date desc limit 1";
			
	$result=query($sql);
	$list='<table class="table table-striped">
	<thead>
      <tr>
        <th>Name</th>
        <th>Mobile </th>
      
      </tr>
    </thead>';
	while($row=fetchArray($result))
	{
		$list.="<tbody>
      <tr>
        <td>".$row["doctorname"]."</td>
        <td><a href='tel:".$row["sweepernumber"]."'>".$row["doctornumber"]."</a></td>
		<td><img src='assets/images/user.png' width='50%' height='50%' /></td>
      </tr>
	 
	  </tbody> ";
	}
	$list.="</table>";
	echo $list;
}


	
?>